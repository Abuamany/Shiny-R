biconv
======

Binary (1-0) Data Converter


### About
You can check out this application here:
- https://langtest4.shinyapps.io/biconv

### Author
[Atsushi MIZUMOTO](http://mizumot.com/ "mizumot.com"), Ph.D.   
Associate Professor of Applied Linguistics  
Faculty of Foreign Language Studies, Kansai University, Osaka, Japan