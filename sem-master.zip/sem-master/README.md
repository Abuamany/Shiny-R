sem
===

Structural Equation Modeling (SEM)


### About
You can check out this application here:
- http://langtest.jp/shiny/sem/

### Author
[Atsushi MIZUMOTO](http://mizumot.com/ "mizumot.com"), Ph.D.   
Associate Professor of Applied Linguistics  
Faculty of Foreign Language Studies, Kansai University, Osaka, Japan