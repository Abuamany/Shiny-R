anova
==

ANOVA


### About
You can check out this application here:
- http://langtest.jp/shiny/anova/

### Author
[Atsushi MIZUMOTO](http://mizumot.com/ "mizumot.com"), Ph.D.   
Associate Professor of Applied Linguistics  
Faculty of Foreign Language Studies, Kansai University, Osaka, Japan