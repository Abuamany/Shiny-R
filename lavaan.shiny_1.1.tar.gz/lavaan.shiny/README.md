# lavaan.shiny
lavaan.shiny: Latent Variable Analysis with Shiny

Currently has options for latent growth curve models, confirmatory factor analysis, and structural equation modeling

## Live demo of lavaan.shiny v1.0 can be found here http://kylehamilton.net/shiny/lavaan.shiny/

#### News about lavaan.shiny

June 23, 2016
* Version 1.1 has been sent to CRAN

March 3, 2016
* Version 1.0 has been sent to CRAN
