# ifaTools

The purpose of `ifaTools` is to collect useful tools for conducting Item Factor Analysis.

`ifaTools` includes 2 shiny apps:

* itemModelExplorer() -- To develop an intuitive sense of item response models
* modelBuilder() -- An easy way to generate code to conduct IFA analysis
