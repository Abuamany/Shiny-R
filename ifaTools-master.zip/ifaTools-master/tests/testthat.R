# NOTE: This will not test an uninstalled package.
library(testthat)
test_check('ifaTools')
